<?php
/**
 * Created by PhpStorm.
 * User: 风哀伤
 * Date: 2019/4/3
 * Time: 10:16
 * @copyright: ©2019 禾匠商城
 * @link: http://www.zjhejiang.com
 */
?>
<div id="app" v-cloak>
    <app-template url="plugin/demo/template/template" add-url="plugin/demo/template/template"
                  submit-url="plugin/demo/template/template"></app-template>
</div>
<script>
    const app = new Vue({
        el: '#app'
    });
</script>
