<?php
/**
 * @copyright ©2018 Lu Wei
 * @author Lu Wei
 * @link http://www.luweiss.com/
 * Created by IntelliJ IDEA
 * Date Time: 2018/10/30 14:46
 */

?>
<link rel="stylesheet" href="<?= \app\helpers\PluginHelper::getPluginBaseAssetsUrl() ?>/css/style.css">
<p><?= $msg ?></p>
<p><?= $demoPost->title ?></p>