<?php
/**
 * @copyright ©2019 浙江禾匠信息科技
 * Created by PhpStorm.
 * User: Andy - Wangjie
 * Date: 2019/10/31
 * Time: 9:25
 */
namespace app\plugins\vip_card\forms\mall;

use app\core\response\ApiCode;
use app\models\Model;
use app\plugins\vip_card\models\VipCardAppointGoods;

class GoodsForm extends Model
{
    public $batch_ids = [];
    public $status;

    public function rules()
    {
        return [
            [['status'], 'integer'],
            [['batch_ids'], 'safe']
        ];
    }

    public function batchUpdateAppoint()
    {
        if ($this->status == 1) {
            $appoint = VipCardAppointGoods::find()->select('goods_id')->where(['goods_id' => $this->batch_ids])->asArray()->all();
            if ($appoint) {
                $goodsIds = array_column($appoint,'goods_id');
                $deal = array_diff($this->batch_ids,$goodsIds);
            } else {
                $deal = $this->batch_ids;
            }
            $adds = [];
            $time = mysql_timestamp();
            foreach ($deal as $v) {
                $temp['id'] = $v;
                $temp['created_at'] = $time;
                $adds[] = $temp;
            }
            $res = \Yii::$app->db->createCommand()->batchInsert(VipCardAppointGoods::tableName(), ['goods_id','created_at'], $adds)->execute();
        } else {
            $res = VipCardAppointGoods::deleteAll(['goods_id' => $this->batch_ids]);
        }

        return [
            'code' => ApiCode::CODE_SUCCESS,
            'msg' => '更新成功',
            'data' => [
                'num' => $res
            ]
        ];
    }
}
