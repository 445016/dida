<?php
/**
 * @copyright ©2019 浙江禾匠信息科技
 * Created by PhpStorm.
 * User: Andy - Wangjie
 * Date: 2019/10/22
 * Time: 9:39
 */
?>

<div id="app" v-cloak>
    <app-template url="plugin/vip_card/mall/setting/template" add-url="plugin/vip_card/mall/setting/template"
                  submit-url="plugin/vip_card/mall/setting/template"></app-template>
</div>
<script>
    const app = new Vue({
    el: '#app'
    });
</script>