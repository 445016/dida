<?php
/**
 * @copyright ©2019 浙江禾匠信息科技
 * Created by PhpStorm.
 * User: Andy - Wangjie
 * Date: 2019/10/22
 * Time: 9:29
 */

namespace app\plugins\vip_card\models;


class TemplateForm extends \app\forms\common\template\TemplateForm
{
    protected function getDefault()
    {
        $iconUrlPrefix = \Yii::$app->request->hostInfo . \Yii::$app->request->baseUrl .
            '/statics/img/mall/tplmsg/';

        $newDefault = [
            [
                'name' => '会员到期提醒',
                'vip_card_remind' => '',
                'tpl_name' => 'vip_card_remind',
                'img_url' => [
                    'wxapp' => $iconUrlPrefix . 'wxapp/svip_expire_tpl.png',
                    'aliapp' => $iconUrlPrefix . 'ttapp/none.png',
                    'bdapp' => $iconUrlPrefix . 'bdapp/svip_expire_tpl.png',
                    'ttapp' => $iconUrlPrefix . 'ttapp/none.png',
                ],
                'platform' => ['wxapp', 'aliapp', 'bdapp', 'ttapp'],
                'tpl_number' => [
                    'wxapp' => '（模板编号：AT1462）',
                    'aliapp' => '',
                    'bdapp' => '（模板编号：BD1382）',
                    'ttapp' => '',
                ]
            ]
        ];

        return $newDefault;
    }

    protected function getTemplateInfo()
    {
        return [
            'wxapp' => [
                'vip_card_remind' => [
                    'id' => 'AT1462',
                    'keyword_id_list' => [4, 2, 13],
                    'title' => '产品到期通知'
                ]
            ],
            'bdapp' => [
                'vip_card_remind' => [
                    'id' => 'BD1382',
                    'keyword_id_list' => [4, 2],
                    'title' => '产品到期通知'
                ]
            ],
        ];
    }
}