(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["plugins/gift/components/announcement/gift-navigation"],{"022c":function(n,t,e){"use strict";e.r(t);var a=e("bfcf"),o=e.n(a);for(var u in a)"default"!==u&&function(n){e.d(t,n,function(){return a[n]})}(u);t["default"]=o.a},"6a21":function(n,t,e){},aaa8:function(n,t,e){"use strict";e.r(t);var a=e("eaa4"),o=e("022c");for(var u in o)"default"!==u&&function(n){e.d(t,n,function(){return o[n]})}(u);e("f1790");var r=e("2877"),c=Object(r["a"])(o["default"],a["a"],a["b"],!1,null,"6183fc10",null);t["default"]=c.exports},bfcf:function(n,t,e){"use strict";(function(n){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var a=function(){return Promise.all([e.e("common/vendor"),e.e("components/basic-component/app-iphone-x/app-iphone-x")]).then(e.bind(null,"7598"))},o={name:"gift-navigation",props:["theme","botHeight","navBool"],data:function(){return{tab_route:"",load_success:!1}},created:function(){var n=getCurrentPages();this.tab_route=n[n.length-1].route},methods:{routeGo:function(t){n.redirectTo({url:t})}},components:{"app-iphone-x":a}};t.default=o}).call(this,e("5486")["default"])},eaa4:function(n,t,e){"use strict";var a=function(){var n=this,t=n.$createElement;n._self._c},o=[];e.d(t,"a",function(){return a}),e.d(t,"b",function(){return o})},f1790:function(n,t,e){"use strict";var a=e("6a21"),o=e.n(a);o.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'plugins/gift/components/announcement/gift-navigation-create-component',
    {
        'plugins/gift/components/announcement/gift-navigation-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('5486')['createComponent'](__webpack_require__("aaa8"))
        })
    },
    [['plugins/gift/components/announcement/gift-navigation-create-component']]
]);                
