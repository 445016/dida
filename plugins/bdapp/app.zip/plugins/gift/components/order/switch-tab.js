(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["plugins/gift/components/order/switch-tab"],{"5e01":function(t,e,n){"use strict";var u=function(){var t=this,e=t.$createElement;t._self._c},a=[];n.d(e,"a",function(){return u}),n.d(e,"b",function(){return a})},"70ce":function(t,e,n){"use strict";var u=n("e744"),a=n.n(u);a.a},"7c1d":function(t,e,n){"use strict";n.r(e);var u=n("5e01"),a=n("b497");for(var r in a)"default"!==r&&function(t){n.d(e,t,function(){return a[t]})}(r);n("70ce");var i=n("2877"),c=Object(i["a"])(a["default"],u["a"],u["b"],!1,null,"d1f3ff4e",null);e["default"]=c.exports},b497:function(t,e,n){"use strict";n.r(e);var u=n("fe37"),a=n.n(u);for(var r in u)"default"!==r&&function(t){n.d(e,t,function(){return u[t]})}(r);e["default"]=a.a},e744:function(t,e,n){},fe37:function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var u={name:"switch-tab",props:{theme:String},data:function(){return{tab_status:0}},methods:{getFormId:function(){},setTab:function(t){this.$emit("setTab",t),this.tab_status=t}}};e.default=u}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'plugins/gift/components/order/switch-tab-create-component',
    {
        'plugins/gift/components/order/switch-tab-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('5486')['createComponent'](__webpack_require__("7c1d"))
        })
    },
    [['plugins/gift/components/order/switch-tab-create-component']]
]);                
