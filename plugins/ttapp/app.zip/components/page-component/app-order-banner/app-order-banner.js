(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/page-component/app-order-banner/app-order-banner"],{"3d08f":function(n,t,e){"use strict";var r=e("625f"),a=e.n(r);a.a},4474:function(n,t,e){"use strict";e.r(t);var r=e("a61e"),a=e.n(r);for(var u in r)"default"!==u&&function(n){e.d(t,n,function(){return r[n]})}(u);t["default"]=a.a},"5ca2":function(n,t,e){"use strict";var r=function(){var n=this,t=n.$createElement;n._self._c},a=[];e.d(t,"a",function(){return r}),e.d(t,"b",function(){return a})},"625f":function(n,t,e){},a61e:function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var r={name:"app-order-banner",data:function(){return{newPicUrl:""}},props:{title:{type:String,value:""},picUrl:{type:String,value:""}},created:function(){this.newPicUrl=this.$store.state.mallConfig.__wxapp_img.mall.order.status_bar}};t.default=r},ccb8:function(n,t,e){"use strict";e.r(t);var r=e("5ca2"),a=e("4474");for(var u in a)"default"!==u&&function(n){e.d(t,n,function(){return a[n]})}(u);e("3d08f");var c=e("2877"),o=Object(c["a"])(a["default"],r["a"],r["b"],!1,null,"5364106e",null);t["default"]=o.exports}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/page-component/app-order-banner/app-order-banner-create-component',
    {
        'components/page-component/app-order-banner/app-order-banner-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('f266')['createComponent'](__webpack_require__("ccb8"))
        })
    },
    [['components/page-component/app-order-banner/app-order-banner-create-component']]
]);                
