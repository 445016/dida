(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/page-component/app-pt-attr/app-pt-attr"],{"051f":function(t,n,e){"use strict";e.r(n);var r=e("f85d"),a=e("5dbd");for(var u in a)"default"!==u&&function(t){e.d(n,t,function(){return a[t]})}(u);e("b791");var o=e("2877"),c=Object(o["a"])(a["default"],r["a"],r["b"],!1,null,"05847065",null);n["default"]=c.exports},"5dbd":function(t,n,e){"use strict";e.r(n);var r=e("e9a6"),a=e.n(r);for(var u in r)"default"!==u&&function(t){e.d(n,t,function(){return r[t]})}(u);n["default"]=a.a},9196:function(t,n,e){},b791:function(t,n,e){"use strict";var r=e("9196"),a=e.n(r);a.a},e9a6:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var r={name:"app-pt-attr",props:{pintuan_groups:{type:Array,default:function(){return[]}},selectGroupAttrId:String},data:function(){return{}},methods:{active:function(t){this.$emit("click",t)}}};n.default=r},f85d:function(t,n,e){"use strict";var r=function(){var t=this,n=t.$createElement;t._self._c},a=[];e.d(n,"a",function(){return r}),e.d(n,"b",function(){return a})}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/page-component/app-pt-attr/app-pt-attr-create-component',
    {
        'components/page-component/app-pt-attr/app-pt-attr-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('f266')['createComponent'](__webpack_require__("051f"))
        })
    },
    [['components/page-component/app-pt-attr/app-pt-attr-create-component']]
]);                
