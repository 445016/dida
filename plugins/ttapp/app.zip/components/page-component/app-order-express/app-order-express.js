(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/page-component/app-order-express/app-order-express"],{2338:function(e,t,n){"use strict";n.r(t);var r=n("e3a2"),a=n("6e92");for(var u in a)"default"!==u&&function(e){n.d(t,e,function(){return a[e]})}(u);n("af4a");var o=n("2877"),f=Object(o["a"])(a["default"],r["a"],r["b"],!1,null,"6721b2f9",null);t["default"]=f.exports},"6e92":function(e,t,n){"use strict";n.r(t);var r=n("caf5"),a=n.n(r);for(var u in r)"default"!==u&&function(e){n.d(t,e,function(){return r[e]})}(u);t["default"]=a.a},"74f9":function(e,t,n){},af4a:function(e,t,n){"use strict";var r=n("74f9"),a=n.n(r);a.a},caf5:function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var r={name:"app-order-express",data:function(){return{}},props:{express:{type:String,value:""},express_no:{type:String,value:""},pageUrl:{type:String,value:""},merchant_remark:{type:String,value:""}}};t.default=r},e3a2:function(e,t,n){"use strict";var r=function(){var e=this,t=e.$createElement;e._self._c},a=[];n.d(t,"a",function(){return r}),n.d(t,"b",function(){return a})}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/page-component/app-order-express/app-order-express-create-component',
    {
        'components/page-component/app-order-express/app-order-express-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('f266')['createComponent'](__webpack_require__("2338"))
        })
    },
    [['components/page-component/app-order-express/app-order-express-create-component']]
]);                
