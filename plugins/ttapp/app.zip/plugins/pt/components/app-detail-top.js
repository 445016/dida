(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["plugins/pt/components/app-detail-top"],{1565:function(n,t,e){"use strict";var r=function(){var n=this,t=n.$createElement;n._self._c},i=[];e.d(t,"a",function(){return r}),e.d(t,"b",function(){return i})},"2e45":function(n,t,e){"use strict";e.r(t);var r=e("fe38"),i=e.n(r);for(var u in r)"default"!==u&&function(n){e.d(t,n,function(){return r[n]})}(u);t["default"]=i.a},"60ce":function(n,t,e){"use strict";e.r(t);var r=e("1565"),i=e("2e45");for(var u in i)"default"!==u&&function(n){e.d(t,n,function(){return i[n]})}(u);e("b280");var a=e("2877"),o=Object(a["a"])(i["default"],r["a"],r["b"],!1,null,"56e4d52a",null);t["default"]=o.exports},"6b4c":function(n,t,e){},b280:function(n,t,e){"use strict";var r=e("6b4c"),i=e.n(r);i.a},fe38:function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var r={name:"app-detail-top",props:{cover_pic:String,name:String,original_price:String,group_min_price:String,people_num:String,status:String,group_economize_price:String}};t.default=r}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'plugins/pt/components/app-detail-top-create-component',
    {
        'plugins/pt/components/app-detail-top-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('f266')['createComponent'](__webpack_require__("60ce"))
        })
    },
    [['plugins/pt/components/app-detail-top-create-component']]
]);                
