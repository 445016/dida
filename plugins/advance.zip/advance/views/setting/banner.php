<?php
?>

<style>

</style>

<div id="app">
    <app-banner url="plugin/advance/mall/setting/banner-store" submit_url="plugin/advance/mall/setting/banner-store"></app-banner>
</div>

<script>
    const app = new Vue({
        el: '#app',
        data() {
            return {

            }
        }
    })
</script>