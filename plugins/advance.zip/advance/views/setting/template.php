<?php
/**
 * Created by PhpStorm.
 * User: 风哀伤
 * Date: 2019/4/3
 * Time: 10:16
 * @copyright: ©2019 浙江禾匠信息科技
 * @link: http://www.zjhejiang.com
 */
?>
<div id="app" v-cloak>
    <app-template url="plugin/advance/mall/setting/template" add-url="plugin/advance/mall/setting/template"
                  submit-url="plugin/advance/mall/setting/template"></app-template>
</div>
<script>
    const app = new Vue({
        el: '#app'
    });
</script>
