<?php
Yii::$app->loadViewComponent('app-order');
?>

<style>

.table-body {
    padding: 20px;
    background-color: #fff;
}
</style>

<div id="app" v-cloak>
    <el-card shadow="never" v-loading="loading"  body-style="background-color: #f3f3f3;padding: 10px 0 0;">
        <div slot="header">
            <span>尾款订单</span>
            <app-export-dialog action_url="index.php?r=plugin/advance/mall/order/index"
                               style="float: right;margin-top: -5px" :field_list='export_list'
                               :params="search">
            </app-export-dialog>
            <el-button style="float: right; margin: -5px 20px" :loading="submit_load" type="primary" size="small"
                       @click="toRecycleAll">清空回收站
            </el-button>
        </div>
        <div class="table-body">
            <app-order v-on:spot="spot" v-on:get="handleClickD" :list="list" :other_list="express_list" :select_list="select_list" url="plugin/advance/mall/order/detail">
                <template slot="tabList">
                    <!-- 订单状态选择 -->
                    <el-tabs v-model="activeName" @tab-click="handleClick">
                        <el-tab-pane label="全部" name="-1"></el-tab-pane>
                        <el-tab-pane label="未付款" name="0"></el-tab-pane>
                        <el-tab-pane label="待发货" name="1"></el-tab-pane>
                        <el-tab-pane label="待收货" name="2"></el-tab-pane>
                        <el-tab-pane label="已完成" name="3"></el-tab-pane>
                        <el-tab-pane label="待处理/待退款" name="4"></el-tab-pane>
                        <el-tab-pane label="已取消" name="5"></el-tab-pane>
                        <el-tab-pane label="回收站" name="7"></el-tab-pane>
                    </el-tabs>
                </template>
            </app-order>
            <div flex="box:last cross:center">
                <div style="visibility: hidden">
                    <el-button plain type="primary" size="small">批量操作1</el-button>
                    <el-button plain type="primary" size="small">批量操作2</el-button>
                </div>
                <div>
                    <el-pagination
                            v-if="pagination"
                            style="display: inline-block;float: right;"
                            background
                            :page-size="pagination.pageSize"
                            @current-change="pageChange"
                            layout="prev, pager, next"
                            :current-page="pagination.current_page"
                            :total="pagination.total_count">
                    </el-pagination>
                </div>
            </div>
        </div>
    </el-card>
</div>

<script>
    const app = new Vue({
        el: '#app',
        data() {
            return {
                loading: false,
                export_list: [],
                search: {},
                submit_load: false,
                list: [],
                activeName: '-1',
                express_list: [],
                pagination: {},
                select_list: [{value: '1', name: '订单号'}, {value: 'advance_no', name: '定金订单号'}, {value: '9', name: '支付单号'}, {
                    value: '2',
                    name: '用户名'
                }, {value: '4', name: '用户ID'}, {value: '5', name: '商品名称'}, {value: '3', name: '收件人'}, {
                    value: '6',
                    name: '收件人电话'
                }, {value: '7', name: '门店名称'}],
                status: -1,
                date_start: '',
                date_end: '',
                platform: '',
                keyword: '',
                keyword_1: '',
                page: 1,
            };
        },
        methods: {
            toRecycleAll() {
                this.$confirm('此操作将永久清空回收站, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning',
                    center: true
                }).then(() => {
                    let para = {
                        r: 'plugin/advance/mall/order/destroy-all'
                    };
                    request({
                        params: para,
                        data: {},
                        method: 'post',
                    }).then(response => {
                        console.log(response);
                        // if (response.data.code === 0) {}
                    });
                    this.$message({
                        type: 'success',
                        message: '清空成功!'
                    });
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消清空回收站'
                    });
                });
            },
            spot(data) {
                this.request(data);
            },
            handleClick() {},
            handleClickD() {
                let para = {
                    r: 'plugin/advance/mall/order/index',
                    status: this.status,
                    date_start: this.date_start,
                    date_end: this.date_end,
                    platform: this.platform,
                    keyword: this.keyword,
                    keyword_1: this.keyword_1,
                    page: this.page,
                };
                request({
                    params: para,
                    method: 'get',
                }).then(response => {
                    this.loading =  false;
                    let { export_list, express_list, list, pagination } = response.data.data;
                    if (response.data.code === 0) {
                        this.export_list = export_list;
                        this.express_list = express_list;
                        this.list = list;
                        this.pagination = pagination;
                    }
                })
            },
            async request(data) {
                this.loading = true;
                let {date_start, date_end, platform, keyword, keyword_1} = data;

                this.date_start = date_start !== undefined ? date_start : this.date_start;
                this.date_end = date_end  !== undefined ? date_end : this.date_end;
                this.platform = platform  !== undefined ? platform : this.platform;
                this.keyword = keyword !== undefined ? keyword : this.keyword;
                this.keyword_1 = keyword_1 !== undefined ? keyword_1 : this.keyword_1;
                let para = {
                    r: 'plugin/advance/mall/order/index',
                    ...data,
                    date_start: this.date_start,
                    date_end: this.date_end,
                    platform: this.platform,
                    keyword: this.keyword,
                    keyword_1: this.keyword_1,
                    page: this.page,
                    status: this.status,
                };
                request({
                    params: para,
                    method: 'get',
                }).then(response => {
                    this.loading =  false;
                    let { export_list, express_list, list, pagination } = response.data.data;
                    if (response.data.code === 0) {
                        this.export_list = export_list;
                        this.express_list = express_list;
                        this.list = list;
                        this.pagination = pagination;
                        this.loading = false;
                    }
                })
            },
            // 分页
            pageChange(page) {
                this.page = page;
                this.loading = true;
                this.list = [];
                let para = {
                    r: 'plugin/advance/mall/order/index',
                    page: this.page,
                    status: this.status,
                    date_start: this.date_start,
                    date_end: this.date_end,
                    platform: this.platform ,
                    keyword: this.keyword,
                    keyword_1: this.keyword_1,
                };
                request({
                    params: para,
                }).then(e => {
                    if (e.data.code === 0) {
                        this.loading = false;
                        this.list = e.data.data.list;
                        this.pagination = e.data.data.pagination;
                        this.express_list = e.data.data.express_list;
                    } else {
                        this.$message.error(e.data.msg);
                    }
                }).catch(e => {
                });
            },
        },
        watch: {
            activeName: {
                handler: function(n,o) {
                    if (n !== o) {
                        this.status = n;
                        this.request({
                            status: n,
                            date_start: this.date_start,
                            date_end: this.date_end,
                            platform: this.platform,
                            keyword: this.keyword,
                            keyword_1: this.keyword_1,
                            page: this.page,
                        })
                    }
                },
                immediate: true,
            }
        }
    });
</script>
