<?php
Yii::$app->loadViewComponent('app-order-detail');
?>

<style>
    [v-cloak]{
        display: none;
    }
    .table-body {
        padding: 10px ;
        background-color: #fff;
    }
</style>

<div id="app" v-cloak>
    <app-order-detail :order="order" :active="active"></app-order-detail>
</div>

<script>
    const app = new Vue({
        el: '#app',
        data() {
            return {
                loading: false,
                order: {},
                active: 2
            }
        },
        created() {
            this.getList();
        },
        methods: {
            //获取列表
            getList() {
                this.loading = true;
                request({
                    params: {
                        r: 'plugin/advance/mall/order/detail',
                        order_id: getQuery('order_id'),
                    },
                }).then(e => {
                    this.loading = false;
                    if (e.data.code === 0) {
                        console.log(e.data.data.order);
                        this.order = e.data.data.order;
                        // console.log(e.data.data.order);
                        if(this.order.cancel_status == 1) {
                            this.active = 5;
                        }
                        if(this.order.is_pay == 1){
                            this.active = 2;
                        }
                        if(this.order.is_send == 1){
                            this.active = 3;
                        }
                        if(this.order.is_confirm == 1){
                            this.active = 4;
                        }
                        if(this.order.is_sale == 1){
                            this.active = 5;
                        }
                    }
                }).catch(e => {
                });
            }
        }
    })
</script>

