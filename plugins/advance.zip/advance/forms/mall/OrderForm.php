<?php
/**
 * @copyright ©2019 浙江禾匠信息科技
 * Created by PhpStorm.
 * User: Andy - Wangjie
 * Date: 2019/9/29
 * Time: 11:50
 */

namespace app\plugins\advance\forms\mall;

use app\forms\mall\order\BaseOrderForm;
use app\plugins\advance\models\AdvanceOrder;

class OrderForm extends BaseOrderForm
{
    protected function getExtra($order)
    {

    }
}
