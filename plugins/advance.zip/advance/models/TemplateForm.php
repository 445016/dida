<?php
/**
 * @copyright ©2019 浙江禾匠信息科技
 * Created by PhpStorm.
 * User: Andy - Wangjie
 * Date: 2019/9/4
 * Time: 9:48
 */


namespace app\plugins\advance\models;


class TemplateForm extends \app\forms\common\template\TemplateForm
{
    protected function getDefault()
    {
        $iconUrlPrefix = \Yii::$app->request->hostInfo . \Yii::$app->request->baseUrl .
            '/statics/img/mall/tplmsg/';

        $newDefault = [
            [
                'name' => '尾款支付提醒',
                'pay_advance_balance' => '',
                'tpl_name' => 'pay_advance_balance',
                'img_url' => [
                    'wxapp' => $iconUrlPrefix . 'wxapp/tailmoney_pay_tpl.png',
                    'aliapp' => $iconUrlPrefix . 'aliapp/tailmoney_pay_tpl.png',
                    'bdapp' => $iconUrlPrefix . 'bdapp/tailmoney_pay_tpl.png',
                    'ttapp' => $iconUrlPrefix . 'ttapp/none.png',
                ],
                'platform' => ['wxapp', 'aliapp', 'bdapp', 'ttapp'],
                'tpl_number' => [
                    'wxapp' => '（模板编号：AT0811）',
                    'aliapp' => '（模板编号：AT0314）',
                    'bdapp' => '（模板编号：BD0768）',
                    'ttapp' => '',
                ]
            ]
        ];

        return $newDefault;
    }

    protected function getTemplateInfo()
    {
        return [
            'wxapp' => [
                'pay_advance_balance' => [
                    'id' => 'AT0811',
                    'keyword_id_list' => [6, 2, 12, 5],
                    'title' => '尾款支付提醒'
                ]
            ],
            'bdapp' => [
                'pay_advance_balance' => [
                    'id' => 'AT0811',
                    'keyword_id_list' => [6, 2, 4, 5],
                    'title' => '尾款支付提醒'
                ]
            ],
        ];
    }
}