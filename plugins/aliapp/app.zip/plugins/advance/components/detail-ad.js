;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["plugins/advance/components/detail-ad"],{"51d4":function(t,e,n){},"54b9":function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var u={name:"detail-ad",props:{sales:{type:Number,default:function(){return 0}},d:{type:Number,default:function(){return 0}},h:{type:Number,default:function(){return 0}},m:{type:Number,default:function(){return 0}},s:{type:Number,default:function(){return 0}}}};e.default=u},8625:function(t,e,n){"use strict";n.r(e);var u=n("54b9"),r=n.n(u);for(var a in u)"default"!==a&&function(t){n.d(e,t,function(){return u[t]})}(a);e["default"]=r.a},"8b65":function(t,e,n){"use strict";var u=n("51d4"),r=n.n(u);r.a},9521:function(t,e,n){"use strict";var u=function(){var t=this,e=t.$createElement;t._self._c},r=[];n.d(e,"a",function(){return u}),n.d(e,"b",function(){return r})},e0a52:function(t,e,n){"use strict";n.r(e);var u=n("9521"),r=n("8625");for(var a in r)"default"!==a&&function(t){n.d(e,t,function(){return r[t]})}(a);n("8b65");var f=n("2877"),c=Object(f["a"])(r["default"],u["a"],u["b"],!1,null,"530e9c7f",null);e["default"]=c.exports}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'plugins/advance/components/detail-ad-create-component',
    {
        'plugins/advance/components/detail-ad-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("e0a52"))
        })
    },
    [['plugins/advance/components/detail-ad-create-component']]
]);                
