;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["plugins/gift/components/index/blessing-message"],{"0474":function(e,n,t){"use strict";t.r(n);var a=t("18f6"),u=t("9c9e");for(var r in u)"default"!==r&&function(e){t.d(n,e,function(){return u[e]})}(r);t("7c43");var s=t("2877"),c=Object(s["a"])(u["default"],a["a"],a["b"],!1,null,"a6e5f400",null);n["default"]=c.exports},"0630":function(e,n,t){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var a={name:"blessing-message",props:["bless_word","place_bless_word"],methods:{changeTextarea:function(e){this.$emit("changeTextarea",e.detail.value)}}};n.default=a},"18f6":function(e,n,t){"use strict";var a=function(){var e=this,n=e.$createElement;e._self._c},u=[];t.d(n,"a",function(){return a}),t.d(n,"b",function(){return u})},"3e92":function(e,n,t){},"7c43":function(e,n,t){"use strict";var a=t("3e92"),u=t.n(a);u.a},"9c9e":function(e,n,t){"use strict";t.r(n);var a=t("0630"),u=t.n(a);for(var r in a)"default"!==r&&function(e){t.d(n,e,function(){return a[e]})}(r);n["default"]=u.a}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'plugins/gift/components/index/blessing-message-create-component',
    {
        'plugins/gift/components/index/blessing-message-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("0474"))
        })
    },
    [['plugins/gift/components/index/blessing-message-create-component']]
]);                
