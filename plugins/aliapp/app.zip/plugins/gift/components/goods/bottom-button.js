;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["plugins/gift/components/goods/bottom-button"],{"180c":function(t,n,e){"use strict";e.r(n);var o=e("2ba0"),u=e.n(o);for(var a in o)"default"!==a&&function(t){e.d(n,t,function(){return o[t]})}(a);n["default"]=u.a},"2ba0":function(t,n,e){"use strict";(function(t){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var e={name:"bottom-button",props:["theme","attr_bool","goods_stock"],methods:{joinGift:function(){this.$emit("attrSwitch",!0)},routeGo:function(){t.reLaunch({url:"/pages/index/index"})}}};n.default=e}).call(this,e("c11b")["default"])},4233:function(t,n,e){"use strict";var o=e("db31"),u=e.n(o);u.a},5446:function(t,n,e){"use strict";e.r(n);var o=e("ba81"),u=e("180c");for(var a in u)"default"!==a&&function(t){e.d(n,t,function(){return u[t]})}(a);e("4233");var i=e("2877"),r=Object(i["a"])(u["default"],o["a"],o["b"],!1,null,"b22d24d6",null);n["default"]=r.exports},ba81:function(t,n,e){"use strict";var o=function(){var t=this,n=t.$createElement;t._self._c},u=[];e.d(n,"a",function(){return o}),e.d(n,"b",function(){return u})},db31:function(t,n,e){}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'plugins/gift/components/goods/bottom-button-create-component',
    {
        'plugins/gift/components/goods/bottom-button-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("5446"))
        })
    },
    [['plugins/gift/components/goods/bottom-button-create-component']]
]);                
