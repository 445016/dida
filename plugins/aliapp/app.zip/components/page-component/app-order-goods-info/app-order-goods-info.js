;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["components/page-component/app-order-goods-info/app-order-goods-info"],{"03f1":function(n,t,e){"use strict";var o=e("c803"),r=e.n(o);r.a},1602:function(n,t,e){"use strict";e.r(t);var o=e("3b78"),r=e("9c56");for(var u in r)"default"!==u&&function(n){e.d(t,n,function(){return r[n]})}(u);e("03f1");var a=e("2877"),c=Object(a["a"])(r["default"],o["a"],o["b"],!1,null,"de2ba672",null);t["default"]=c.exports},"3b78":function(n,t,e){"use strict";var o=function(){var n=this,t=n.$createElement;n._self._c},r=[];e.d(t,"a",function(){return o}),e.d(t,"b",function(){return r})},"5a2d":function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var o={name:"app-order-goods-info",data:function(){return{}},props:{goods:{type:Object,default:{}},plugin:{type:String,default:""}}};t.default=o},"9c56":function(n,t,e){"use strict";e.r(t);var o=e("5a2d"),r=e.n(o);for(var u in o)"default"!==u&&function(n){e.d(t,n,function(){return o[n]})}(u);t["default"]=r.a},c803:function(n,t,e){}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'components/page-component/app-order-goods-info/app-order-goods-info-create-component',
    {
        'components/page-component/app-order-goods-info/app-order-goods-info-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("1602"))
        })
    },
    [['components/page-component/app-order-goods-info/app-order-goods-info-create-component']]
]);                
