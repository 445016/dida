;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["components/page-component/app-rule/app-rule"],{1136:function(n,t,e){"use strict";var r=function(){var n=this,t=n.$createElement;n._self._c},u=[];e.d(t,"a",function(){return r}),e.d(t,"b",function(){return u})},"20f1":function(n,t,e){},4756:function(n,t,e){"use strict";e.r(t);var r=e("9759"),u=e.n(r);for(var o in r)"default"!==o&&function(n){e.d(t,n,function(){return r[n]})}(o);t["default"]=u.a},"761a":function(n,t,e){"use strict";e.r(t);var r=e("1136"),u=e("4756");for(var o in u)"default"!==o&&function(n){e.d(t,n,function(){return u[n]})}(o);e("f20f");var a=e("2877"),c=Object(a["a"])(u["default"],r["a"],r["b"],!1,null,"30520944",null);t["default"]=c.exports},9759:function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var r=function(){return Promise.all([e.e("common/vendor"),e.e("components/basic-component/app-rich/parse")]).then(e.bind(null,"cb0e"))},u={name:"app-rule",props:{title:String,content:String,is_title:{type:Boolean,default:!1}},components:{"app-rich-text":r}};t.default=u},f20f:function(n,t,e){"use strict";var r=e("20f1"),u=e.n(r);u.a}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'components/page-component/app-rule/app-rule-create-component',
    {
        'components/page-component/app-rule/app-rule-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("761a"))
        })
    },
    [['components/page-component/app-rule/app-rule-create-component']]
]);                
